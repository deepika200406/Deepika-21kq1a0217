Python 3.12.1 (tags/v3.12.1:2305ca5, Dec  7 2023, 22:03:25) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\my lap\OneDrive\Desktop\PYTHON\project.py
20
enter student name: deepika
enter roll number: 1
enter student marks: 5 6 4
enter student name: rahi
enter roll number: 2
enter student marks: 6 5 7
enter student name: navya
enter roll number: 3
enter student marks: 6 7 5
enter student name: hema
enter roll number: 4
enter student marks: 9 4 3
enter student name: sruthi
enter roll number: 5
enter student marks: 7 5 4
enter student name: jyothi
enter roll number: 6
enter student marks: 7 5 8
enter student name: jahnavi
enter roll number: 7
enter student marks: 9 4 2
enter student name: devi
enter roll number: 8
enter student marks: 7 6 4
enter student name: tiru
enter roll number: 9
enter student marks: 5 8 9
enter student name: kala
enter roll number: 10
enter student marks: 7 4 9
enter student name: megha
enter roll number: 11
enter student marks: 8 5 7
enter student name: harika
enter roll number: 12
enter student marks: 9 5 3
enter student name: divya
enter roll number: 13
enter student marks: 8 5 6
enter student name: pooji
enter roll number: 14
enter student marks: 7 5 8
enter student name: jaya
enter roll number: 15
enter student marks: 8 6 4
enter student name: kavya
enter roll number: 16
enter student marks: 5 7 4
enter student name: leela
enter roll number: 17
enter student marks: 7 3 9
enter student name: varshi
enter roll number: 18
enter student marks: 9 4 6
enter student name: sweety
enter roll number: 19
enter student marks: 6 4 7
enter student name: chitti
enter roll number: 20
enter student marks: 5 7 8
       name  rollnumber      marks  total
0   deepika           1  [5, 6, 4]     15
1      rahi           2  [6, 5, 7]     18
2     navya           3  [6, 7, 5]     18
3      hema           4  [9, 4, 3]     16
4    sruthi           5  [7, 5, 4]     16
5    jyothi           6  [7, 5, 8]     20
6   jahnavi           7  [9, 4, 2]     15
7      devi           8  [7, 6, 4]     17
8      tiru           9  [5, 8, 9]     22
9      kala          10  [7, 4, 9]     20
10    megha          11  [8, 5, 7]     20
11   harika          12  [9, 5, 3]     17
12    divya          13  [8, 5, 6]     19
13    pooji          14  [7, 5, 8]     20
14     jaya          15  [8, 6, 4]     18
15    kavya          16  [5, 7, 4]     16
16    leela          17  [7, 3, 9]     19
17   varshi          18  [9, 4, 6]     19
18   sweety          19  [6, 4, 7]     17
19   chitti          20  [5, 7, 8]     20
max total=: 22
min total=: 15
sort total=: [15, 15, 16, 16, 16, 17, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 20, 20, 20, 22]
{15, 16, 17, 18, 19, 20, 22}
maximum score of student1: 6
minimum score of student1: 4
total score of student1: 15
average score of student1: 5.0
sort of all marks 1: [4, 5, 6]
score of each subject without duplicates: {4, 5, 6}
maximum score of student2: 7
minimum score of student2: 5
total score of student2: 18
average score of student2: 6.0
sort of all marks 2: [5, 6, 7]
score of each subject without duplicates: {5, 6, 7}
maximum score of student3: 7
minimum score of student3: 5
total score of student3: 18
average score of student3: 6.0
sort of all marks 3: [5, 6, 7]
score of each subject without duplicates: {5, 6, 7}
maximum score of student4: 9
minimum score of student4: 3
total score of student4: 16
average score of student4: 5.333333333333333
sort of all marks 4: [3, 4, 9]
score of each subject without duplicates: {9, 3, 4}
maximum score of student5: 7
minimum score of student5: 4
total score of student5: 16
average score of student5: 5.333333333333333
sort of all marks 5: [4, 5, 7]
score of each subject without duplicates: {4, 5, 7}
maximum score of student6: 8
minimum score of student6: 5
total score of student6: 20
average score of student6: 6.666666666666667
sort of all marks 6: [5, 7, 8]
score of each subject without duplicates: {8, 5, 7}
maximum score of student7: 9
minimum score of student7: 2
total score of student7: 15
average score of student7: 5.0
sort of all marks 7: [2, 4, 9]
score of each subject without duplicates: {9, 2, 4}
maximum score of student8: 7
minimum score of student8: 4
total score of student8: 17
average score of student8: 5.666666666666667
sort of all marks 8: [4, 6, 7]
score of each subject without duplicates: {4, 6, 7}
maximum score of student9: 9
minimum score of student9: 5
total score of student9: 22
average score of student9: 7.333333333333333
sort of all marks 9: [5, 8, 9]
score of each subject without duplicates: {8, 9, 5}
maximum score of student10: 9
minimum score of student10: 4
total score of student10: 20
average score of student10: 6.666666666666667
sort of all marks 10: [4, 7, 9]
score of each subject without duplicates: {9, 4, 7}
maximum score of student11: 8
minimum score of student11: 5
total score of student11: 20
average score of student11: 6.666666666666667
sort of all marks 11: [5, 7, 8]
score of each subject without duplicates: {8, 5, 7}
maximum score of student12: 9
minimum score of student12: 3
total score of student12: 17
average score of student12: 5.666666666666667
sort of all marks 12: [3, 5, 9]
score of each subject without duplicates: {9, 3, 5}
maximum score of student13: 8
minimum score of student13: 5
total score of student13: 19
average score of student13: 6.333333333333333
sort of all marks 13: [5, 6, 8]
score of each subject without duplicates: {8, 5, 6}
maximum score of student14: 8
minimum score of student14: 5
total score of student14: 20
average score of student14: 6.666666666666667
sort of all marks 14: [5, 7, 8]
score of each subject without duplicates: {8, 5, 7}
maximum score of student15: 8
minimum score of student15: 4
total score of student15: 18
average score of student15: 6.0
sort of all marks 15: [4, 6, 8]
score of each subject without duplicates: {8, 4, 6}
maximum score of student16: 7
minimum score of student16: 4
total score of student16: 16
average score of student16: 5.333333333333333
sort of all marks 16: [4, 5, 7]
score of each subject without duplicates: {4, 5, 7}
maximum score of student17: 9
minimum score of student17: 3
total score of student17: 19
average score of student17: 6.333333333333333
sort of all marks 17: [3, 7, 9]
score of each subject without duplicates: {9, 3, 7}
maximum score of student18: 9
minimum score of student18: 4
total score of student18: 19
average score of student18: 6.333333333333333
sort of all marks 18: [4, 6, 9]
score of each subject without duplicates: {9, 4, 6}
maximum score of student19: 7
minimum score of student19: 4
total score of student19: 17
average score of student19: 5.666666666666667
sort of all marks 19: [4, 6, 7]
score of each subject without duplicates: {4, 6, 7}
maximum score of student20: 8
minimum score of student20: 5
total score of student20: 20
average score of student20: 6.666666666666667
sort of all marks 20: [5, 7, 8]
score of each subject without duplicates: {8, 5, 7}
maximum marks in subject 1: 5
maximum marks in subject 2: 8
maximum marks in subject 3: 9
